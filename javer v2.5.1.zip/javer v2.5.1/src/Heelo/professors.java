package Heelo;

import java.util.ArrayList;
import java.util.List;

public class professors extends Users{
	List<String> courses = new ArrayList<String>();

	/**
	 *
	 * @param username
	 * @param name
	 * @param department
	 */
	public professors(String username,String name,String  department) {
		super(username,name,department);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Courses courses1 = new Courses("math",12,2);
		Courses.updatel_List();
//na valo tin lista stous proffesors kai students
	}

}

