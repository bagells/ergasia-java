package Heelo;

public class grades{
    int grade;
    int exam_period;
    String student;

}
//course_name
