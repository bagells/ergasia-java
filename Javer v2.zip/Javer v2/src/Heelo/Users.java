package Heelo;
public abstract class Users {
	String username;
	String name;
	String  department;
	int counter ;//na ajanetai kata ena kathe fora pou kaleitai o constructors //isos ayti i metavlitli prepei na einai global
	public Users(String username,String name,String  department){
		
	}
	
	int getcounter(){
		return counter;
		
	}
	void setcounter(int a) {
		counter =a ;
		
	}
	String getcusername(){
		return username;
		
	}String getname(){
		return name;
		
	}String getdepartment(){
		return department;
		
	}
	
	

}

