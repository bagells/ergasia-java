package Heelo;

public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hellow world2");
		fileReader.read("/home/meow/eclipse-workspace/Javer/src/Heelo/Untitled1.txt");
		
		students kostas = new students("kostas","kostasname","plhroforiki",24098);	
		

	}

}
