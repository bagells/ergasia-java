package Heelo;

public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hellow world2");

	}

}
