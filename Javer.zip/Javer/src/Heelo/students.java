package Heelo;

public class students extends Users{
	int registrationNumber;

	public students(int reggie) {
		registrationNumber =reggie ;
		
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
