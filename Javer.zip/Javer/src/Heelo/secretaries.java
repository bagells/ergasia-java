package Heelo;

public class secretaries extends Users{

	public secretaries() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
