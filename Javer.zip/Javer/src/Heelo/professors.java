package Heelo;

public class professors extends Users{
	List<String> = new List<String>;

	public professors() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
